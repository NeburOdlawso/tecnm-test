const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const port = 27017;

const uri = 'mongodb://localhost:27017/interprocsys';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

async function conectarMongoDB() {
    try {
        await client.connect();
        console.log('Conexión a MongoDB establecida');
    } catch (error) {
        console.error('Error al conectar a MongoDB', error);
    }
}

conectarMongoDB();

app.get('/', async (req, res) => {
    const db = client.db(); // Obtiene la base de datos
    const coleccion = db.collection('usuarios'); // Reemplaza con el nombre de tu colección

    try {
        const datos = await coleccion.find({}).toArray();
        res.render('index', { datos });
    } catch (error) {
        console.error('Error al obtener datos de MongoDB', error);
        res.status(500).send('Error interno del servidor');
    }
});

app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');